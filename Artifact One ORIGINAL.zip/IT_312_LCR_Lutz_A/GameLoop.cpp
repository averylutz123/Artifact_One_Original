//------------------------------------------------------------------------------------------------------------
// GameLoop.cpp contains all the actual game play mechanics for LCR to function. It is tied to the "Game" class
// and each function used within this cpp file is declared within the GameLoop.h header file. Game is one of 
// three functions utilized in this program, the others being Player and DiceOptions.
//------------------------------------------------------------------------------------------------------------

#include "GameLoop.h"
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <vector>
#include <string>
#include <fstream>                                 // Utilized to read file.
#using<system.dll>                                 // Compile in CLR.

using namespace System;                            // Accessed with CLR.
using namespace System::IO;
using namespace std;


///// Function that organizes the game play mechanics and acts as an anchor to every additional function /////
void Game::RunGame()
{
	// Declare variables utilized within this main function.
	int numberOfPlayers;
	int dieValue;
	int totalChips;
	int numberOfRolls;
	char direction;
	bool quitGame = false;
	vector <int> pointVector;
	vector <string> playerNames;
	srand(time(0));

	// Call function that will read the instructions to the players.
	readInstructions();

	// Call function to obtain the number of players. 
	numberOfPlayers = askPlayerNumber();

	// Call function that obtains the names of the players.
	playerNames = askPlayerNames(numberOfPlayers);

	// Add players to game and give them all three chips.
	for (int i = 0; i < numberOfPlayers; ++i) {
		pointVector.push_back(i);
		pointVector[i] = 3;
	}


	// Calculate the total number of chips based on the number of players.
	totalChips = numberOfPlayers * 3;


	// Game keeps going until one player has all the chips.
	while (quitGame == false) {

		// Inform the users about the number of chips they all have.
		cout << endl;
		for (int i = 0; i < pointVector.size(); ++i) {
			cout << setw(20) << left << playerNames[i] + ":"  << pointVector[i] << " chips" << endl;
		}

		// Allow each player to take turns rolling the dice.
		for (int i = 0; i < pointVector.size(); ++i) {

			politeQuestion(i, playerNames);
			numberOfRolls = calculateRolls(pointVector, i);

			for (int y = 0; y < numberOfRolls; ++y){
				cout << "Roll " << y + 1 << ": ";
				dieValue = rollTheDie();                                             // Function that rolls the die.
				direction = directionOfPass(dieValue);                               // Function that assigns direction.
				pointVector = gamePlay(pointVector, i, numberOfPlayers, direction);  // Function that moves chips. 

				// If direction is 'C' the total number of chips has to decrease.
				if (direction == 'C') {
					totalChips = totalChips - 1;
				}
			}
			
			// Allow players to vizualize their chips.
			for (int i = 0; i < pointVector.size(); ++i) {
				cout << "\n" << setw(20) << left << playerNames[i] + ":";         // I like having this to actually see
				for (int y = 0; y < pointVector[i]; ++y) {                        // "chips" moving. It makes the game
					cout << " O";                                                 // a bit more vizually interesting.
				}
			}

			cout << endl;
			quitGame = isThereAWinner(pointVector, totalChips, playerNames);      // Function to check for a winner.
			if (quitGame)
			{
				// Display the final values of the game. All but one player will have zero chips.
				cout << "\nEnd Results:" << endl;
				for (int i = 0; i < pointVector.size(); ++i) {
					cout << setw(20) << left << playerNames[i] + ":" << pointVector[i] << " chips" << endl;
				}
				break;
			}
		}
	}
} ///// END OF RunGame Function /////



///// Function that reads the game instructions to the players /////
void Game :: readInstructions() {
	String^ fileName = "LCR_Text_File.txt";                    // Reference the name of the file we are reading.

	try
	{
		StreamReader^ din = File::OpenText(fileName);          // Open the file.

		String^ str;
		int count = 0;
		while ((str = din->ReadLine()) != nullptr)             // Loop through each line of the file.
		{
			count++;
			Console::WriteLine("{1}", count, str);             // Display the file contents to the user.
		}
	}
	catch (Exception^ e)                                       // Ensure there are backup messages if there 
	{                                                          // is a problem opening the file.
		if (dynamic_cast<FileNotFoundException^>(e))
			Console::WriteLine("file '{0}' not found", fileName);
		else
			Console::WriteLine("problem reading file '{0}'", fileName);
	}
}



///// Function that asks the user to enter the number of players for the game /////
int Game :: askPlayerNumber() {

	// Variable to hold the number of players.
	int numberOfPlayers;

	// Ask for the user's input. Reference value in Player class.
	cout << "\nPlease enter the number of individuals who will be playing: ";
	cin >> numberOfPlayers;
	m_player.SetPlayerNumber(numberOfPlayers);


	// Ensure there are at least three players. Call value set in Player class.
	while (m_player.GetPlayerNumber() < 3) {
		cout << "\nA minimum of three players is required for this game. Please add " <<
			"more players.\nPlease enter the number of individuals who will be playing: ";
		cin >> numberOfPlayers;
		m_player.SetPlayerNumber(numberOfPlayers);
	}

	return numberOfPlayers;
}



///// Function that asks for the names of each participant. /////
vector <string> Game :: askPlayerNames(int numberOfPlayers) {

	string name;
	vector <string> playerNames;

	// Loop through each player to obtain their name.
	for (int i = 0; i < numberOfPlayers; ++i) {
		cout << "Please enter the name of player " << i + 1 << ": ";
		cin >> name;
		m_player.SetName(name);
		playerNames.push_back(m_player.GetName());
	}
	return playerNames;
}



///// Function that asks the player if they want to roll their dice. /////
void Game:: politeQuestion(int i, vector <string> playerNames) {

	string likeToRoll;
	int response = (rand() % 4) + 1;

	// This function makes the user manually choose to keep playing. This helps with the pacing of 
	// the game and allows us to see what is actually happening throughout each round.
	cout << "\n" << playerNames[i] << ", it is your turn to roll the die..." <<
		"\nWould you like to roll ('y' or 'n'): ";
	cin >> likeToRoll;
	
	if (likeToRoll == "y") {
		cout << endl;
	}

	// Make the responses more interesting so its not necesarrily the same each time.
	// This was just an additional fun section to make the game flow better.
	else if (likeToRoll == "n") {
		if (response == 1) {
			cout << "Sorry, you have to participate." << endl;
		}
		else if (response == 2) {
			cout << "There are no winners yet." << endl;
		}
		else if (response == 3) {
			cout << "Why not???" << endl;
		}
		else {
			cout << "This question was just to be polite." << endl;
		}
		cout << endl;
	}
	else {
		cout << "We could not recognize your response, but it is still your turn to roll.\n" << endl;
	}
}



///// Function that calculates the number of rolls aloted to individual players /////
int Game:: calculateRolls(vector <int> pointVector, int i) {

	int numberOfRolls;

	// Based off game instructions, there are three die. The number of chips the current 
	// player has will reflect the number of dice they are allowed to roll.
	if (pointVector[i] == 0) {
		cout << "I'm sorry... You currently do not have any chips," <<
			" we must skip your turn until you are given more." << endl;
		numberOfRolls = 0;
	}
	else if (pointVector[i] == 1) {                                // One chip equals one roll.
		cout << "You may only roll one die this turn." << endl;
		numberOfRolls = 1;
	}  
	else if (pointVector[i] == 2) {                                // Two chips equals two rolls.
		cout << "You may only roll two dice this turn." << endl;
		numberOfRolls = 2;
	}
	else {                                                         // Three or more chips equals three rolls.
		cout << "You may roll three dice." << endl;
		numberOfRolls = 3;
	}
	return numberOfRolls;
}



///// Function that rolls the die and generate a random value /////
int Game:: rollTheDie() {

	// Randomly define the die value and return it back to main.
	int dieValue = (rand() % 6) + 1;
	m_player.SetDieValue(dieValue);
	cout << " The die rolled a " << m_player.GetDieValue() << endl;
	
	return dieValue;
}



///// Function that gives direction of chip pass depending on die value /////
char Game:: directionOfPass(int dieValue) {

	DiceOptions DeterminedOption = DiceOptions::None;
	char direction;

	if (dieValue == 1) {              // If the die rolls a 1, the player passes a chip left.
		direction = 'L';
		cout << "You must pass one chip to the player sitting to your left." << endl;
		DeterminedOption = DiceOptions::Left;
	}
	else if (dieValue == 2) {         // If the die rolls a 2, the player passes a chip right.
		direction = 'R';
		cout << "You must pass one chip to the player sitting to your right." << endl;
		DeterminedOption = DiceOptions::Right;
	}
	else if (dieValue == 3) {         // If the die rolls a 3, the player passes a chip center.
		direction = 'C';
		cout << "You must put one chip in the center pot. This chip is now out of play." << endl;
		DeterminedOption = DiceOptions::Center;
	}
	else {                            // If the die rolls a 4, 5, or 6, nothing happens.
		direction = '*';
		cout << "You must not take any action for this die." << endl;
	}

	cout << endl;
	return direction;
}



///// Function that completes all the actual chip moving and game play (Left and Right) /////
vector <int> Game:: gamePlay(vector <int> pointVector, int i, int numberOfPlayers, char direction) {

	// Every move except '*', the player loses a chip.
	if (direction != '*') {

		pointVector[i] = pointVector[i] - 1;

		// Must take into account player one, whose 'left' is last player.
		// Player to the left gains one chip.
		if (direction == 'L') {
			if (i == 0) {
				pointVector[numberOfPlayers - 1] = pointVector[numberOfPlayers - 1] + 1;
			}
			else {
				pointVector[i - 1] = pointVector[i - 1] + 1;
			}
		}
		// Must take into account the last player's 'right' is player 1.
		// Player to the right gains one chip.
		else if (direction == 'R') {
			if (i == (numberOfPlayers - 1)) {
				pointVector[0] = pointVector[0] + 1;
			}
			else {
				pointVector[i + 1] = pointVector[i + 1] + 1;
			}
		}
	}
	return pointVector;
}



///// Function that determines whether or not there is a current winnter of the game /////
bool Game:: isThereAWinner(vector <int> pointVector, int totalChips, vector <string> playerNames) {

	bool winner = false;

	// Loop through each player's points to see if anyone has all available chips.
	// Announce the winning player if there is one.
	for (int i = 0; i < pointVector.size(); ++i) {
		if (pointVector[i] == totalChips) {

			cout << "\nCongratulations " << playerNames[i] << "!!! You are the " <<
				    "last remaining player with chips and have won the game!!" << 
			 	    "\nThanks for playing everyone!!" << endl;
			winner = true;
			break;
		}
	}
	return winner;
}
