#pragma once

#include "Player.h"
#include "DiceOptions.h"
#include <vector>

class Game
{
private:

	Player m_player;            // This will be used to connect the Player and Game classess.

	// Declare the functions utilized within the Game class.
	void readInstructions();
	int askPlayerNumber();
	vector <string> askPlayerNames(int numberOfPlayers);
	void politeQuestion(int i, vector <string> playerNames);
	int calculateRolls(vector <int> pointVector, int i);
	int rollTheDie();
	char directionOfPass(int dieValue);
	vector <int> gamePlay(vector <int> pointVector, int i, int numberOfPlayers, char direction);
	bool isThereAWinner(vector <int> pointVector, int totalChips, vector <string> playerNames);

public:
	void RunGame();             // This function acts as the central method for the entire program.
};

