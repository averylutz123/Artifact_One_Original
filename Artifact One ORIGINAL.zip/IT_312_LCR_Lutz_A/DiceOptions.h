#pragma once


// Just the potential ways in which the chips can be passed for each roll.
enum class DiceOptions
{
	Left,
	Right,
	Center,
	None
};