#pragma once

#include <string>
using namespace std;

class Player
{
private:
	int m_playerNumber;
	int m_dieValue;
	string m_name;

public:
	Player()
	{
	}

	void SetPlayerNumber(const int& playerNumber)    // Accept the numberOfPlayers value given from GameLoop.cpp
	{
		m_playerNumber = playerNumber;
	}

	const int& GetPlayerNumber() const               // Return numberOfPlayers value that was set in previous function.
	{
		return m_playerNumber;
	}

	void SetName(const std::string& name)            // Accept the player's name given from GameLoop.cpp
	{
		m_name = name;
	}

	const std::string& GetName() const               // Return player's name that was set in previous function.
	{
		return m_name;
	}

	void SetDieValue (const int& dieValue)           // Accept the value of the die given from GameLoop.cpp.
	{
		m_dieValue = dieValue;
	}

	const int& GetDieValue() const                   // Return die value that was set in previous function.
	{
		return m_dieValue;
	}
};