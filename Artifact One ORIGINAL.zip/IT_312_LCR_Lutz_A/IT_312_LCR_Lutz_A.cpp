//------------------------------------------------------------------------------------------------------------
// Name:     Avery Lutz
// Course:   IT-312-J3248
// Project:  Assignment 7-1 Final Project (LCR Game)
// Purpose:  Allow three or more players to participate in the LCR game by rolling dice and passing chips.
// Created:  February 15, 2022
//------------------------------------------------------------------------------------------------------------

// IT_312_LCR_Lutz_A.cpp : This file contains the 'main' function. Program execution begins and ends there.


#include <cstdlib>
#include "GameLoop.h"
using namespace std;

int main()
{
	Game game;                              // The Game class contains all essential gameplay componenets.
	game.RunGame();                         // RunGame is the primary method of the program.

	return 0;
}

